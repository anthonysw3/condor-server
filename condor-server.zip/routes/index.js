var express = require("express");
var router = express.Router();
var { DuffelError } = require("@duffel/api");
var duffel = require("../duffel");

router.post("/search", async (req, res) => {
  const { outbound, returnJourney, cabin_class, passengers } = req.body;

  // Validate the outbound data
  if (
    !outbound ||
    !outbound.origin ||
    !outbound.destination ||
    !outbound.date
  ) {
    res.sendStatus(422);
    return;
  }

  try {
    // Create an array of slices for the outbound and (optional) return journey
    const slices = [
      {
        origin: outbound.origin,
        destination: outbound.destination,
        departure_date: outbound.date,
      },
    ];

    // If there's a return journey, add it to the slices array
    if (
      returnJourney &&
      returnJourney.origin &&
      returnJourney.destination &&
      returnJourney.date
    ) {
      slices.push({
        origin: returnJourney.origin,
        destination: returnJourney.destination,
        departure_date: returnJourney.date,
      });
    }

    const offerRequestsResponse = await duffel.offerRequests.create({
      slices: slices,
      cabin_class: cabin_class,
      passengers: passengers,
      return_offers: false,
    });

    const offersResponse = await duffel.offers.list({
      offer_request_id: offerRequestsResponse.data.id,
      limit: 200, // Set the limit to 50 (default)
    });

    const results = offersResponse.data || [];

    res.send({
      offersResponse: {
        data: results,
      },
    });
  } catch (e) {
    console.error(e);
    if (e instanceof DuffelError) {
      res.status(e.meta.status).send({ errors: e.errors });
      return;
    }

    res.status(500).send(e);
  }
});

{
  /* router.post("/search", async (req, res) => {
  const { outbound, returnJourney, cabin_class, passengers } = req.body;

  // Validate the outbound data
  if (
    !outbound ||
    !outbound.origin ||
    !outbound.destination ||
    !outbound.date
  ) {
    res.sendStatus(422);
    return;
  }

  try {
    // Create an array of slices for the outbound and (optional) return journey
    const slices = [
      {
        origin: outbound.origin,
        destination: outbound.destination,
        departure_date: outbound.date,
      },
    ];

    // If there's a return journey, add it to the slices array
    if (
      returnJourney &&
      returnJourney.origin &&
      returnJourney.destination &&
      returnJourney.date
    ) {
      slices.push({
        origin: returnJourney.origin,
        destination: returnJourney.destination,
        departure_date: returnJourney.date,
      });
    }

    const offerRequestsResponse = await duffel.offerRequests.create({
      slices: slices,
      cabin_class: cabin_class,
      passengers: passengers,
      return_offers: false,
    });

    let after = null;
    const results = [];

    // Function to delay the execution
    const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

    while (true) {
      // Add a delay of 1 second before each API call
      await delay(1000);

      // Only include the `after` parameter if it's not `null`
      // const offersResponse = after
      //  ? await duffel.offers.list({
      //      offer_request_id: offerRequestsResponse.data.id,
      //      limit: 5,
      //      after: after,
      //     })
      //  : await duffel.offers.list({
      //      offer_request_id: offerRequestsResponse.data.id,
      //      limit: 5,
      //    });

      const offersResponse = await duffel.offers.list({
        offer_request_id: offerRequestsResponse.data.id,
        limit: 5,
      });

      console.log("Offers Response: ", offersResponse);

      if (
        !offersResponse ||
        !offersResponse.data ||
        offersResponse.data.length === 0
      ) {
        break;
      }

      results.push(...offersResponse.data);

      if (!offersResponse.meta || !offersResponse.meta.after) {
        break;
      }

      console.log("After value: ", offersResponse.meta.after);

      after = offersResponse.meta.after;
    }

    res.send({
      offersResponse: {
        data: results,
      },
    });
  } catch (e) {
    console.error(e);
    if (e instanceof DuffelError) {
      res.status(e.meta.status).send({ errors: e.errors });
      return;
    }

    res.status(500).send(e);
  }
}); */
}

router.post("/book", async (req, res) => {
  const { passengers, offerId, currency, amount } = req.body;
  try {
    const response = await duffel.orders.create({
      selected_offers: [offerId],
      passengers,
      type: "instant",
      payments: [
        {
          type: "balance",
          currency: currency,
          amount: amount,
        },
      ],
    });

    res.send({ order: response.data });
  } catch (e) {
    console.error(e);
    if (e instanceof DuffelError) {
      res.status(e.meta.status).send({ errors: e.errors });
      return;
    }
    res.status(500).send(e);
  }
});

module.exports = router;
